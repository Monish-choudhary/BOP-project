
import java.io.*;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Loginservlet {
	
	//create a bean object here
	
	public void doGet(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
		      
		      // Set response content type
		      response.setContentType("text/html");
		      String name = request.getParameter("uname");
		      String password = request.getParameter("pass");
		      
		      // pass the values into the  service class function 
		      
		      String message ="Loged In Succesfully";
		      // Actual logic goes here.
		      PrintWriter out = response.getWriter();
		      out.println("<h1>" + message + "</h1>");
		   }

}

