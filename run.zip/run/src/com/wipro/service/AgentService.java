package com.wipro.service;

import com.wipro.bean.AdminBean;
import com.wipro.dao.AdminDao;

public class AgentService {
	
	public String insertAdmin(AdminBean bean) {
		String s = "";
		
		AdminDao dao = new AdminDao();
		int n = dao.insertAdmin(bean);
		
		if(n>=1) {
			s= "success";
		}
		else {
			s = "fail";
		}
		
		return s;
	}
	
	public boolean checkPass(int id, String pas) {
		boolean pass = false;
		AdminDao dao = new AdminDao();
		
		String s = dao.checkPass(id);
		if( s.equals(pas)) {
			pass = true;
		}
		else if( s != null || s!="not found") {
			pass=  false;
		}
		else {
			pass = false;
		}
		return pass;
		
		
		
		
	}
}
