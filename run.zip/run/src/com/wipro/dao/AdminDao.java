package com.wipro.dao;

import java.sql.*;
import java.util.*;

import com.wipro.bean.AdminBean;
import com.wipro.util.DBUtil;

public class AdminDao {
	Connection con;
	PreparedStatement ps;
	ResultSet rs;
	int n=0;
	
	public int insertAdmin( AdminBean adminBean) {
		
		con = DBUtil.getDBConnection();
		try {
			String sql = "insert into fm_admin_details values(?, ?, ?)";
			ps = con.prepareStatement(sql);
			ps.setInt(1, adminBean.getAdminId());
			ps.setString(2, adminBean.getAdminName());
			ps.setString(2, adminBean.getAdminPass());
			 n= ps.executeUpdate();
			 
			 rs.close();
			 ps.close();
			 con.close();
			 
			
		} catch (Exception e) {
			System.out.println(e);
		}
		return n;
	}
	
	public ArrayList<AdminBean> showAllAdmin( ) {
		con = DBUtil.getDBConnection();
		ArrayList<AdminBean> list = new ArrayList<AdminBean>();
		String sql = "select A_USERID, A_NAME from fm_admin_details";
		try {
			
			ps = con.prepareStatement(sql);
			rs = ps.executeQuery();
			while(rs.next()) {
				AdminBean bean = new AdminBean();
				bean.setAdminId(rs.getInt("A_USERID"));
				bean.setAdminName(rs.getString("A_NAME"));
				list.add(bean);
			}
			rs.close();
			ps.close();
			con.close();
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		return list;		
		
	}
	
	public String checkPass( int adminId ) {
		String sql  = "select A_PASSWORD from fm_admin_details where A_USERID =? ";
		con = DBUtil.getDBConnection();
		String pass= "not found";
		  try {
			ps = con.prepareStatement(sql);
			ps.setInt(1, adminId);
			
			rs = ps.executeQuery();
			if(rs.next()) {
				pass = rs.getString(1);
			}
			rs.close();
			ps.close();
			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		  return pass;
		
	}
	
	

}
