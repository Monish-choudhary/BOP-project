package com.wipro.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.wipro.bean.AdminBean;
import com.wipro.bean.UserBean;
import com.wipro.util.DBUtil;

public class UserDao {
	Connection con;
	PreparedStatement ps;
	ResultSet rs;
	
	int n=0;
	
	public int insertUser( UserBean userBean) {
		
		con = DBUtil.getDBConnection();
		try {
			String sql = "insert into fm_user_details values(?, ?, ?, ?, ?)";
			ps = con.prepareStatement(sql);
			ps.setString(1, userBean.getUserId());
			ps.setString(2, userBean.getUserPassword());
			ps.setInt(3, userBean.getUserNo());
			ps.setString(4, userBean.getUserName());
			ps.setInt(5, userBean.getUserAge());
			
			n = ps.executeUpdate();
			
			ps.close();
			rs.close();
			con.close();
			
		} catch (Exception e) {
			System.out.println(e);
		}
		return n;
	}
	
	
	public UserBean userDetail( String userid) {
		
		String sql = "select * from fm_user_details where U_USERID=?";
		con = DBUtil.getDBConnection();
		UserBean bean = new UserBean();
		try {
			ps = con.prepareStatement(sql);
			ps.setString(1, userid);
			
			rs = ps.executeQuery();
			
			if(rs.next()) {
				bean = null;
				bean.setUserId(rs.getString("U_USERID"));
				bean.setUserPassword(rs.getString("U_PASSWORD"));
				bean.setUserNo(rs.getInt("U_NO"));
				bean.setUserName(rs.getString("U_NAME"));
				bean.setUserAge(rs.getInt("U_AGE"));
				
			}
			
		ps.close();
		rs.close();
		con.close();
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		return bean;
		
		
	}

}
