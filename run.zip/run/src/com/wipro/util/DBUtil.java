package com.wipro.util;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBUtil {
	
	public static Connection getDBConnection() {
		Connection connection = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			connection = DriverManager.getConnection("jdbc:oracle:thin:@10.209.61.132:1521:orcl", "scott", "tiger");
		} catch (Exception e) {
			System.out.println(e);
		}
		return connection;
	}
	

}
//10.200.20.110:1521