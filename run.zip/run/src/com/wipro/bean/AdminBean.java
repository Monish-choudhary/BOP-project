package com.wipro.bean;

public class AdminBean {
	private int adminId;
	private String adminPass;
	private String adminName;
	
	public AdminBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public int getAdminId() {
		return adminId;
	}
	
	public AdminBean(int adminId, String adminPass, String adminName) {
		super();
		this.adminId = adminId;
		this.adminPass = adminPass;
		this.adminName = adminName;
	}

	public void setAdminId(int adminId) {
		this.adminId = adminId;
	}
	
	public String getAdminPass() {
		return adminPass;
	}
	
	public void setAdminPass(String adminPass) {
		this.adminPass = adminPass;
	}
	
	public String getAdminName() {
		return adminName;
	}
	
	

	public void setAdminName(String adminName) {
		this.adminName = adminName;
	}
	
	
	

}
