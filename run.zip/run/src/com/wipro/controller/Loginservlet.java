package com.wipro.controller;

import java.io.*;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.wipro.service.AgentService;

public class Loginservlet extends HttpServlet {
	
	//create a bean object here
	
	public void doPost(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
		      
		      // Set response content type
		      response.setContentType("text/html");
		      String name = request.getParameter("uname");
		     
		      
		      String trigerFrom = request.getParameter("loginbtn");
		      
		      if(trigerFrom.equals("submit")) {
		    	  String password = request.getParameter("pass");
		    	  
		    	  
		      }
		      
		      AgentService srv = new AgentService();
		      
		      
		      
		      
		      // pass the values into the  service class function 
		      
		      String message ="Loged In Succesfully";
		      // Actual logic goes here.
		      PrintWriter out = response.getWriter();
		      out.println("<h1>" + message + "</h1>");
		   }

}

