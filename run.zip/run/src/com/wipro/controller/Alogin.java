package com.wipro.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.wipro.service.AgentService;

/**
 * Servlet implementation class Alogin
 */
public class Alogin extends HttpServlet {
	
       
	public void doPost(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
	      
	      // Set response content type
	      response.setContentType("text/html");
	      String name = request.getParameter("aid");
	      int id = Integer.parseInt(name);
	     
	      
	      String trigerFrom = request.getParameter("Aloginbtn");
	      PrintWriter out = response.getWriter();
	      
	      if(trigerFrom.equals("submitAgent")) {
	    	  String password = request.getParameter("pass");
	    	  
	    	  AgentService srv = new AgentService();
	    	  boolean b = srv.checkPass(id , password);
	    	  
	    	  if(b == true) {
	    		  String message ="Loged In Succesfully";
	    	      // Actual logic goes here.
	    	      
	    	      out.println("<h1>" + message + "</h1>");  
	    	  }
	    	  else
	    	  {
	    		  String message ="Wrong Password";
	    	      // Actual logic goes here.
	    	      
	    	      out.println("<h1>" + message + "</h1>");
	    	  }
	    	  
	    	  
	    	  
	      }
	      
	      
	      
	      
	      
	      
	      // pass the values into the  service class function 
	      
	      
	   }

}
